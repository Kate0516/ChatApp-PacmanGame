# **Pac-Man *-- by Team Quicksilver***


## **Team members**
**Team Lead:**           Bill Huang<br>
**Tech Lead:**           Jerry Zhang<br>
**Doc Lead:**            Zhengtong Liu<br>
**Frontend Developer:**  Jeff Zhou, Yang Zhou<br>
**Backend Developer:**   Lou Jianing, Zhen Gao

Deployed on Heroku: https://pacman-final-team-quicksilver.herokuapp.com/


## Unit test covering more than 90% line of code in model
![](resources/unit_test1.png)

![](resources/unit_test2.png)
