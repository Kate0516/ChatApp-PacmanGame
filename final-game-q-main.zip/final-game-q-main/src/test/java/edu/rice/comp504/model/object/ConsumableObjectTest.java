package edu.rice.comp504.model.object;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ConsumableObjectTest {

    @Test
    void getLocation() {
    }

    @Test
    void propertyChange() {
    }

    @Test
    void getObjectType() {
    }
}