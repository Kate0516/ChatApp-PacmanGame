package edu.rice.comp504.model.object;

public enum Direction {
    UP,
    DOWN,
    LEFT,
    RIGHT
}