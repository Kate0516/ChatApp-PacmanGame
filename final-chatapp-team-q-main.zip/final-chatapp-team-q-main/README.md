# Quickchat
### *-- start a quick chat with your soulmate*


### Team members
**Team Lead:**           Bill Huang <br>
**Tech Lead:**           Yang Zhou <br>
**Doc Lead:**            Zhen Gao <br>
**Frontend Developer:**  Jeff Zhou, Jianing Lou <br>
**Backend Developer:**   Jerry Zhang, Zhengtong Liu <br>

<br>

**Heroku app url:** https://chatapp-final-team-quickchat.herokuapp.com


# final-chatapp-team-q


## Test coverage 
Test covering more than 85% line of code
![img](img.png)

