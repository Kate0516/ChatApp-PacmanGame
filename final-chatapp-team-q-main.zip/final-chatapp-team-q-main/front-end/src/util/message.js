import {message} from "antd";


export const error = (msg) => {
    message.error(msg);
};

export const success = (msg) => {
    message.success(msg);
};