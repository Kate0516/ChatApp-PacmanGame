package edu.rice.comp504.model.message;

//It is unnecessary to include tests for Message class because all methods in this class are either getter or setter
public class MessageTest {
}
